export LD_LIBRARY_PATH=$PWD
./darknet detect yolov3-odla.cfg yolov3-odla.cfg data/person.jpg
